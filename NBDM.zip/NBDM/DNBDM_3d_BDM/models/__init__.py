from .basic_template import TrainTask
from models.corediff.corediff import corediff

model_dict = {
    'corediff': corediff,
}
